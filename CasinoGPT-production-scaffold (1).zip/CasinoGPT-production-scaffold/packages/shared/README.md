# Shared Package

Common types and utilities.
