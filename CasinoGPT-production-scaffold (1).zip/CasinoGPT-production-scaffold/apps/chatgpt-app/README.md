# ChatGPT App

Frontend MCP app integration.
